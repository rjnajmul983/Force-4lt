package com.forcenet.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.graphics.Typeface;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final int[] MODE_TITLE = {
            R.string.mode_auto, R.string.mode_4g, R.string.mode_3g, R.string.mode_5g, R.string.mode_2g};
    private static final int[] MODE_DESC = {
            R.string.mode_auto_d, R.string.mode_4g_d, R.string.mode_3g_d, R.string.mode_5g_d, R.string.mode_2g_d};
    // Names as shown in the hidden "Set preferred network type" list
    private static final String[] MODE_HINT = {
            "NR/LTE/GSM/WCDMA\n(" + "LTE/GSM/WCDMA)", "LTE only", "WCDMA only", "NR only", "GSM only"};

    private static final String[][] RADIO_TARGETS = {
            {"com.android.phone", "com.android.phone.settings.RadioInfo"},
            {"com.android.settings", "com.android.settings.RadioInfo"},
            {"com.android.settings", "com.android.settings.Settings$TestingSettingsActivity"}
    };

    private TextView statusValue;
    private TextView statusSub;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            handler.postDelayed(this, 2000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        requestPhonePermission();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refreshStatus();
    }

    // ---------- UI ----------

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(getColor(R.color.bg));
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            int top;
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets i = insets.getInsets(WindowInsets.Type.systemBars());
                top = i.top;
                bottom = i.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(0, top, 0, bottom);
            return insets;
        });

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(root, new ViewGroup.LayoutParams(MATCH, WRAP));

        root.addView(tv(getString(R.string.app_name), 30, R.color.text, true));
        TextView sub = tv(getString(R.string.subtitle), 14, R.color.sub, false);
        sub.setPadding(0, dp(2), 0, dp(18));
        root.addView(sub);

        // Status card
        LinearLayout status = card();
        status.addView(tv(getString(R.string.current_network), 13, R.color.sub, false));
        statusValue = tv("—", 30, R.color.accent, true);
        status.addView(statusValue);
        statusSub = tv("", 12, R.color.sub, false);
        status.addView(statusSub);
        status.setOnClickListener(v -> requestPhonePermission());
        root.addView(status);

        TextView h1 = tv(getString(R.string.choose_mode), 15, R.color.sub, true);
        h1.setPadding(dp(4), dp(10), 0, dp(8));
        root.addView(h1);

        for (int i = 0; i < MODE_TITLE.length; i++) {
            final int idx = i;
            LinearLayout c = card();
            c.addView(tv(getString(MODE_TITLE[i]), 17, R.color.text, true));
            c.addView(tv(getString(MODE_DESC[i]), 13, R.color.sub, false));
            c.setOnClickListener(v -> showModeDialog(idx));
            root.addView(c);
        }

        TextView h2 = tv(getString(R.string.tools), 15, R.color.sub, true);
        h2.setPadding(dp(4), dp(14), 0, dp(8));
        root.addView(h2);

        root.addView(actionCard(R.string.open_radio, v -> {
            if (!openRadioInfo()) {
                Toast.makeText(this, R.string.fail_msg, Toast.LENGTH_LONG).show();
                openDialer();
            }
        }));
        root.addView(actionCard(R.string.open_dialer, v -> openDialer()));
        root.addView(actionCard(R.string.open_settings, v -> openNetworkSettings()));

        TextView note = tv(getString(R.string.note), 12, R.color.sub, false);
        note.setPadding(dp(4), dp(12), dp(4), 0);
        root.addView(note);

        setContentView(scroll);
    }

    private LinearLayout actionCard(int textRes, View.OnClickListener l) {
        LinearLayout c = card();
        c.addView(tv(getString(textRes), 15, R.color.accent, true));
        c.setOnClickListener(l);
        return c;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(16), dp(18), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(getColor(R.color.card));
        bg.setCornerRadius(dp(18));
        c.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22888888), bg, null));
        c.setClickable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.bottomMargin = dp(10);
        c.setLayoutParams(lp);
        return c;
    }

    private TextView tv(String text, int sp, int colorRes, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(getColor(colorRes));
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    // ---------- Actions ----------

    private void showModeDialog(int idx) {
        new AlertDialog.Builder(this)
                .setTitle(MODE_TITLE[idx])
                .setMessage(getString(R.string.pick_msg, MODE_HINT[idx]))
                .setPositiveButton(R.string.btn_open, (d, w) -> {
                    if (!openRadioInfo()) {
                        Toast.makeText(this, R.string.fail_msg, Toast.LENGTH_LONG).show();
                        openDialer();
                    }
                })
                .setNegativeButton(R.string.btn_cancel, null)
                .show();
    }

    private boolean openRadioInfo() {
        for (String[] t : RADIO_TARGETS) {
            try {
                Intent i = new Intent();
                i.setComponent(new ComponentName(t[0], t[1]));
                startActivity(i);
                return true;
            } catch (Exception ignored) {
                // try next one
            }
        }
        return false;
    }

    private void openDialer() {
        try {
            startActivity(new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", "*#*#4636#*#*", null)));
        } catch (Exception e) {
            openNetworkSettings();
        }
    }

    private void openNetworkSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
            } catch (Exception ignored) {
                // nothing else to try
            }
        }
    }

    // ---------- Status ----------

    private void requestPhonePermission() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE}, 1);
        }
    }

    private void refreshStatus() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            statusValue.setText("—");
            statusSub.setText(R.string.status_no_perm);
            return;
        }
        try {
            TelephonyManager tm = getSystemService(TelephonyManager.class);
            statusValue.setText(label(tm.getDataNetworkType()));
            statusSub.setText(R.string.status_hint);
        } catch (SecurityException e) {
            statusValue.setText("—");
            statusSub.setText(R.string.status_no_perm);
        }
    }

    private static String label(int type) {
        switch (type) {
            case TelephonyManager.NETWORK_TYPE_NR:
                return "5G";
            case TelephonyManager.NETWORK_TYPE_LTE:
            case 19: // LTE_CA
                return "4G LTE";
            case TelephonyManager.NETWORK_TYPE_UMTS:
            case TelephonyManager.NETWORK_TYPE_HSDPA:
            case TelephonyManager.NETWORK_TYPE_HSUPA:
            case TelephonyManager.NETWORK_TYPE_HSPA:
            case TelephonyManager.NETWORK_TYPE_HSPAP:
            case TelephonyManager.NETWORK_TYPE_TD_SCDMA:
            case TelephonyManager.NETWORK_TYPE_EVDO_0:
            case TelephonyManager.NETWORK_TYPE_EVDO_A:
            case TelephonyManager.NETWORK_TYPE_EVDO_B:
            case TelephonyManager.NETWORK_TYPE_EHRPD:
                return "3G";
            case TelephonyManager.NETWORK_TYPE_GPRS:
            case TelephonyManager.NETWORK_TYPE_EDGE:
            case TelephonyManager.NETWORK_TYPE_CDMA:
            case TelephonyManager.NETWORK_TYPE_1xRTT:
            case TelephonyManager.NETWORK_TYPE_IDEN:
            case TelephonyManager.NETWORK_TYPE_GSM:
                return "2G";
            case TelephonyManager.NETWORK_TYPE_IWLAN:
                return "Wi-Fi Calling";
            default:
                return "—";
        }
    }
}
