package com.forcenet.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {

    private static final int REQ_PERM = 101;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final String[][] RADIO_TARGETS = {
            {"com.android.phone", "com.android.phone.settings.RadioInfo"},
            {"com.android.settings", "com.android.settings.RadioInfo"},
            {"com.android.settings", "com.android.settings.Settings$TestingSettingsActivity"}
    };

    private static final int[] MODE_TITLE = {
            R.string.mode_4g, R.string.mode_5g, R.string.mode_3g, R.string.mode_2g, R.string.mode_auto
    };
    private static final int[] MODE_DESC = {
            R.string.mode_4g_d, R.string.mode_5g_d, R.string.mode_3g_d, R.string.mode_2g_d, R.string.mode_auto_d
    };
    private static final String[] MODE_HINT = {
            "LTE only",
            "NR only",
            "WCDMA only",
            "GSM only",
            "NR/LTE/GSM/WCDMA (LTE/GSM/WCDMA)"
    };

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            handler.postDelayed(this, 2500);
        }
    };

    // Selected SIM slot: 0 = SIM 1 (Phone 0), 1 = SIM 2 (Phone 1)
    private int selectedSlot = 0;
    private int[] slotSubIds = {-1, -1};
    private String[] slotCarrierNames = {"", ""};

    private LinearLayout sim1Btn;
    private LinearLayout sim2Btn;
    private TextView sim1Title;
    private TextView sim1Sub;
    private TextView sim2Title;
    private TextView sim2Sub;

    private TextView statusLabel;
    private TextView statusValue;
    private TextView statusSub;
    private TextView settingsBtnTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        if (!hasPhonePerm()) {
            requestPhonePermission();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        handler.postDelayed(ticker, 2500);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    private boolean hasPhonePerm() {
        return checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPhonePermission() {
        requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE}, REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refreshStatus();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(getColor(R.color.bg));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(28));
        root.setClipToPadding(false);

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                top = insets.getInsets(WindowInsets.Type.systemBars()).top;
                bottom = insets.getInsets(WindowInsets.Type.systemBars()).bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(dp(20), top + dp(16), dp(20), bottom + dp(24));
            return insets;
        });

        // Header
        TextView title = new TextView(this);
        title.setText(R.string.app_name);
        title.setTextColor(getColor(R.color.text));
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText(R.string.subtitle);
        subtitle.setTextColor(getColor(R.color.sub));
        subtitle.setTextSize(14);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        subLp.bottomMargin = dp(18);
        root.addView(subtitle, subLp);

        // SIM Selector Section
        root.addView(sectionLabel(getString(R.string.select_sim)));

        LinearLayout simRow = new LinearLayout(this);
        simRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rowLp.bottomMargin = dp(16);

        sim1Btn = createSimButton(0);
        sim2Btn = createSimButton(1);

        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lp1.rightMargin = dp(6);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lp2.leftMargin = dp(6);

        simRow.addView(sim1Btn, lp1);
        simRow.addView(sim2Btn, lp2);
        root.addView(simRow, rowLp);

        // Live Status Card
        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        statusCard.setPadding(dp(18), dp(16), dp(18), dp(16));
        statusCard.setBackground(roundedRipple(getColor(R.color.card), dp(16)));
        statusCard.setClickable(true);
        statusCard.setOnClickListener(v -> {
            if (!hasPhonePerm()) {
                requestPhonePermission();
            } else {
                refreshStatus();
            }
        });

        statusLabel = new TextView(this);
        statusLabel.setTextColor(getColor(R.color.sub));
        statusLabel.setTextSize(13);
        statusCard.addView(statusLabel);

        statusValue = new TextView(this);
        statusValue.setText("--");
        statusValue.setTextColor(getColor(R.color.accent));
        statusValue.setTextSize(26);
        statusValue.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams valLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        valLp.topMargin = dp(4);
        valLp.bottomMargin = dp(4);
        statusCard.addView(statusValue, valLp);

        statusSub = new TextView(this);
        statusSub.setText(R.string.status_hint);
        statusSub.setTextColor(getColor(R.color.sub));
        statusSub.setTextSize(12);
        statusCard.addView(statusSub);

        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        statusLp.bottomMargin = dp(20);
        root.addView(statusCard, statusLp);

        // Mode Selection Section
        root.addView(sectionLabel(getString(R.string.choose_mode)));
        for (int i = 0; i < MODE_TITLE.length; i++) {
            final int idx = i;
            root.addView(actionCard(getString(MODE_TITLE[i]), getString(MODE_DESC[i]), v -> showModeDialog(idx)));
        }

        // Other Tools Section
        LinearLayout.LayoutParams toolsLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        toolsLp.topMargin = dp(12);
        toolsLp.bottomMargin = dp(8);
        TextView toolsHeader = sectionLabel(getString(R.string.tools));
        root.addView(toolsHeader, toolsLp);

        root.addView(actionCard(getString(R.string.open_radio), null, v -> openRadioInfo()));
        root.addView(actionCard(getString(R.string.open_dialer), null, v -> openDialer()));

        LinearLayout settingsCard = actionCard(getString(R.string.open_settings, getSelectedSimLabel()), null, v -> openNetworkSettings());
        settingsBtnTitle = (TextView) settingsCard.getChildAt(0);
        root.addView(settingsCard);

        // Note
        TextView note = new TextView(this);
        note.setText(R.string.note);
        note.setTextColor(getColor(R.color.sub));
        note.setTextSize(12);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        noteLp.topMargin = dp(14);
        root.addView(note, noteLp);

        scroll.addView(root, new ViewGroup.LayoutParams(MATCH, WRAP));
        setContentView(scroll);

        updateSimButtonStyles();
    }

    private LinearLayout createSimButton(final int slotIndex) {
        LinearLayout btn = new LinearLayout(this);
        btn.setOrientation(LinearLayout.VERTICAL);
        btn.setPadding(dp(14), dp(12), dp(14), dp(12));
        btn.setClickable(true);
        btn.setOnClickListener(v -> {
            selectedSlot = slotIndex;
            updateSimButtonStyles();
            refreshStatus();
        });

        TextView t = new TextView(this);
        t.setText(slotIndex == 0 ? R.string.sim_1 : R.string.sim_2);
        t.setTextColor(getColor(R.color.text));
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        btn.addView(t);

        TextView s = new TextView(this);
        s.setText("Phone " + slotIndex);
        s.setTextColor(getColor(R.color.sub));
        s.setTextSize(12);
        btn.addView(s);

        if (slotIndex == 0) {
            sim1Title = t;
            sim1Sub = s;
        } else {
            sim2Title = t;
            sim2Sub = s;
        }
        return btn;
    }

    private void updateSimButtonStyles() {
        int activeBg = getColor(R.color.card_active);
        int idleBg = getColor(R.color.card);
        int activeSub = getColor(R.color.text);
        int idleSub = getColor(R.color.sub);

        sim1Btn.setBackground(roundedRipple(selectedSlot == 0 ? activeBg : idleBg, dp(14)));
        sim2Btn.setBackground(roundedRipple(selectedSlot == 1 ? activeBg : idleBg, dp(14)));
        sim1Sub.setTextColor(selectedSlot == 0 ? activeSub : idleSub);
        sim2Sub.setTextColor(selectedSlot == 1 ? activeSub : idleSub);

        if (settingsBtnTitle != null) {
            settingsBtnTitle.setText(getString(R.string.open_settings, getSelectedSimLabel()));
        }
    }

    private String getSelectedSimLabel() {
        String base = getString(selectedSlot == 0 ? R.string.sim_1 : R.string.sim_2);
        String carrier = slotCarrierNames[selectedSlot];
        if (carrier != null && !carrier.isEmpty()) {
            return base + " • " + carrier;
        }
        return base;
    }

    private TextView sectionLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(getColor(R.color.sub));
        tv.setTextSize(13);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.bottomMargin = dp(8);
        tv.setLayoutParams(lp);
        return tv;
    }

    private LinearLayout actionCard(String label, String desc, View.OnClickListener click) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(roundedRipple(getColor(R.color.card), dp(14)));
        card.setClickable(true);
        card.setOnClickListener(click);

        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(getColor(R.color.text));
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(t);

        if (desc != null) {
            TextView d = new TextView(this);
            d.setText(desc);
            d.setTextColor(getColor(R.color.sub));
            d.setTextSize(13);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(MATCH, WRAP);
            dlp.topMargin = dp(2);
            card.addView(d, dlp);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.bottomMargin = dp(10);
        card.setLayoutParams(lp);
        return card;
    }

    private RippleDrawable roundedRipple(int bgColor, int radiusPx) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(bgColor);
        shape.setCornerRadius(radiusPx);
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape, null);
    }

    private void refreshStatus() {
        statusLabel.setText(getString(R.string.current_network, getSelectedSimLabel()));

        if (!hasPhonePerm()) {
            statusValue.setText("--");
            statusSub.setText(R.string.status_no_perm);
            sim1Sub.setText("Phone 0");
            sim2Sub.setText("Phone 1");
            return;
        }

        slotSubIds[0] = -1;
        slotSubIds[1] = -1;
        slotCarrierNames[0] = "";
        slotCarrierNames[1] = "";

        try {
            SubscriptionManager sm = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
            if (sm != null) {
                List<SubscriptionInfo> list = sm.getActiveSubscriptionInfoList();
                if (list != null) {
                    for (SubscriptionInfo info : list) {
                        int slot = info.getSimSlotIndex();
                        if (slot == 0 || slot == 1) {
                            slotSubIds[slot] = info.getSubscriptionId();
                            CharSequence name = info.getCarrierName();
                            slotCarrierNames[slot] = (name != null) ? name.toString() : "";
                        }
                    }
                }
            }
        } catch (SecurityException ignored) {
        }

        sim1Sub.setText(slotSubIds[0] != -1
                ? (slotCarrierNames[0].isEmpty() ? "Phone 0" : slotCarrierNames[0] + " (Phone 0)")
                : getString(R.string.sim_empty) + " (Phone 0)");
        sim2Sub.setText(slotSubIds[1] != -1
                ? (slotCarrierNames[1].isEmpty() ? "Phone 1" : slotCarrierNames[1] + " (Phone 1)")
                : getString(R.string.sim_empty) + " (Phone 1)");

        statusLabel.setText(getString(R.string.current_network, getSelectedSimLabel()));
        if (settingsBtnTitle != null) {
            settingsBtnTitle.setText(getString(R.string.open_settings, getSelectedSimLabel()));
        }

        try {
            TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) {
                statusValue.setText("--");
                return;
            }
            int subId = slotSubIds[selectedSlot];
            if (subId != -1) {
                tm = tm.createForSubscriptionId(subId);
                int type = tm.getDataNetworkType();
                statusValue.setText(networkTypeName(type));
                statusSub.setText(R.string.status_hint);
            } else {
                statusValue.setText(R.string.sim_empty);
                statusSub.setText("Phone " + selectedSlot);
            }
        } catch (SecurityException e) {
            statusValue.setText("--");
            statusSub.setText(R.string.status_no_perm);
        }
    }

    private String networkTypeName(int type) {
        switch (type) {
            case TelephonyManager.NETWORK_TYPE_NR:
                return "5G NR";
            case TelephonyManager.NETWORK_TYPE_LTE:
                return "4G LTE";
            case TelephonyManager.NETWORK_TYPE_HSPAP:
            case TelephonyManager.NETWORK_TYPE_HSPA:
            case TelephonyManager.NETWORK_TYPE_HSDPA:
            case TelephonyManager.NETWORK_TYPE_HSUPA:
            case TelephonyManager.NETWORK_TYPE_UMTS:
                return "3G";
            case TelephonyManager.NETWORK_TYPE_EDGE:
            case TelephonyManager.NETWORK_TYPE_GPRS:
            case TelephonyManager.NETWORK_TYPE_GSM:
                return "2G";
            case TelephonyManager.NETWORK_TYPE_IWLAN:
                return "Wi-Fi Calling";
            default:
                return "Unknown / No Data";
        }
    }

    private void showModeDialog(int idx) {
        String phoneIndexName = "Phone " + selectedSlot;
        String msg = getString(R.string.pick_msg_sim, getSelectedSimLabel(), phoneIndexName, MODE_HINT[idx]);
        new AlertDialog.Builder(this)
                .setTitle(MODE_TITLE[idx])
                .setMessage(msg)
                .setPositiveButton(R.string.btn_open, (d, w) -> openRadioInfo())
                .setNegativeButton(R.string.btn_cancel, null)
                .show();
    }

    private void openRadioInfo() {
        for (String[] target : RADIO_TARGETS) {
            try {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(target[0], target[1]));
                intent.putExtra("phone_id", selectedSlot);
                if (slotSubIds[selectedSlot] != -1) {
                    intent.putExtra(Settings.EXTRA_SUB_ID, slotSubIds[selectedSlot]);
                }
                startActivity(intent);
                return;
            } catch (Exception ignored) {
            }
        }
        Toast.makeText(this, R.string.fail_msg, Toast.LENGTH_LONG).show();
        openDialer();
    }

    private void openDialer() {
        try {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.fromParts("tel", "*#*#4636#*#*", null));
            startActivity(intent);
        } catch (Exception ignored) {
        }
    }

    private void openNetworkSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS);
            if (slotSubIds[selectedSlot] != -1) {
                intent.putExtra(Settings.EXTRA_SUB_ID, slotSubIds[selectedSlot]);
            }
            startActivity(intent);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }
}
